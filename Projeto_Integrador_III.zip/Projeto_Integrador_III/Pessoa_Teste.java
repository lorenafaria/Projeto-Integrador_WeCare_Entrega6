package Testes;

import projeto_integrador_iii.Pessoa;

public class Pessoa_Teste {

	public static void main (String[] args) {
		Pessoa p1 = new Pessoa();
		p1.nome = "Marco Junior";
		p1.endereco = "R. Jos� Cl�udio Rezende, 420 - Estoril, Belo Horizonte ";
		p1.eelefone = "+55 (31) 3516-2300";
		p1.dt_nascimento = "06/06/1994";
		p1.cpf = "123.456.789.00";
		p1.status();
		}
	}