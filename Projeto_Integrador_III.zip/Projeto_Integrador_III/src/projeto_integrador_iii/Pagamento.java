package projeto_integrador_iii;
// Definição
public class Pagamento {
  
  // Atributos
  
  private int  id_forma_pagamento;
  public String desc_forma_pagamento;
 
  // Construtor da classe
  public Pagamento() {
    this.setId_forma_pagamento(id_forma_pagamento);
    this.setDesc_forma_pagamento(desc_forma_pagamento);
  }

  public void status () {
	   	System.out.println("forma de Pagamento: " + this.desc_forma_pagamento);
  }

public int getId_forma_pagamento() {
	return id_forma_pagamento;
}


public void setId_forma_pagamento(int id_forma_pagamento) {
	this.id_forma_pagamento = id_forma_pagamento;
}


public String getDesc_forma_pagamento() {
	return desc_forma_pagamento;
}


public void setDesc_forma_pagamento(String desc_forma_pagamento) {
	this.desc_forma_pagamento = desc_forma_pagamento;
} 
}