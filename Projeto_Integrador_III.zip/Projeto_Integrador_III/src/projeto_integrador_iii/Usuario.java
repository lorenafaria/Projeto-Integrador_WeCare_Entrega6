package projeto_integrador_iii;
// Definição
public class Usuario {
  
   public String nome;
   public String senha;
   public String login;
   
   	public void status () {
   	System.out.println("Usu�rio " + this.login);
 	System.out.println("Senha ********");
 	System.out.println("Nome " + this.nome);
   	}
public String getNome() {
	return nome;
}

public void setNome(String nome) {
	this.nome = nome;
}

public String getSenha() {
	return senha;
}

public void setSenha(String i) {
	this.senha = i;
}

public String getLogin() {
	return login;
}

public void setLogin(String login) {
	this.login = login;
}
}