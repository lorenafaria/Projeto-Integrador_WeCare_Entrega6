package projeto_integrador_iii;
// Definição
public class Curriculo {
  
  // Atributos
  
  public String experiencia;
  public String qualificacoes;
  public String vl_servico;

  // Construtor da classe
  public Curriculo () {
	  this.qualificacoes(qualificacoes);
	  this.vl_servico(vl_servico);
  }
  public void status () {
	   	System.out.println("Experiencia: " + this.experiencia);
	 	System.out.println("Qualificacoes: " + this.qualificacoes);
	 	System.out.println("Valor do Servico: " + this.vl_servico);
	   	}

private void qualificacoes(String qualificacoes2) {
	// TODO Auto-generated method stub
	
}

private void vl_servico(String vl_servico2) {
	// TODO Auto-generated method stub
	
}  
}
