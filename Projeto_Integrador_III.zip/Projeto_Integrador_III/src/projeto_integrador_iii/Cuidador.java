package projeto_integrador_iii;
// Definição
public class Cuidador {

  // Atributos
  public String cuidador;
  public String usuario;
  public String agenda;
  public String curriculo;
  

  // Construtor da classe
  public Cuidador () {
    this.cuidador(cuidador);
    this.usuario(usuario);
    this.Agenda(agenda);
    this.Curriculo(curriculo); 
    
  }
  public void status () {
	   	System.out.println("Cuidador: " + this.cuidador);
	 	System.out.println("Usuario: " + this.usuario);
	 	System.out.println("Agenda: " + this.agenda);
	 	System.out.println("Curriculo: " + this.curriculo);
	   	}

private void Curriculo(String curriculo2) {
	// TODO Auto-generated method stub
	
}

private void Agenda(String agenda2) {
	// TODO Auto-generated method stub
	
}

private void usuario(String usuario2) {
	// TODO Auto-generated method stub
	
}

private void cuidador(String cuidador2) {
	// TODO Auto-generated method stub
	
}

public String getCuidador() {
	return cuidador;
}

public void setCuidador(String cuidador) {
	this.cuidador = cuidador;
}

public String getUsuario() {
	return usuario;
}

public void setUsuario(String usuario) {
	this.usuario = usuario;
}

public String getAgenda() {
	return agenda;
}

public void setAgenda(String agenda) {
	this.agenda = agenda;
}

public String getCurriculo() {
	return curriculo;
}

public void setCurriculo(String curriculo) {
	this.curriculo = curriculo;
}
}
