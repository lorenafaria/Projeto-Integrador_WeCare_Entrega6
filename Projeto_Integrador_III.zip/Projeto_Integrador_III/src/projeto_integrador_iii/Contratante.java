package projeto_integrador_iii;
// Definição
public class Contratante {

  // Atributos
  private int id_contratante;
  private int id_usuario;
  private int id_forma_pagamento;
  public String servico;
  public String cuidador;

  // Construtor da classe
  public Contratante (int id_contratante, int id_usuario, int id_forma_pagamento, String servico, String cuidador) {
    this.setId_contratante(id_contratante);
    this.setId_usuario(id_usuario);
    this.setId_forma_pagamento(id_forma_pagamento);
    this.setServico(servico);
    this.setCuidador(cuidador);
    
  }
	public Contratante() {
	// TODO Auto-generated constructor stub
}
	public void status () {
	   	System.out.println("Servico: " + this.servico);
	 	System.out.println("Cuidador: " + this.cuidador);
	   	}

public int getId_usuario() {
	return id_usuario;
}

public void setId_usuario(int id_usuario) {
	this.id_usuario = id_usuario;
}

public int getId_contratante() {
	return id_contratante;
}

public void setId_contratante(int id_contratante) {
	this.id_contratante = id_contratante;
}

public int getId_forma_pagamento() {
	return id_forma_pagamento;
}

public void setId_forma_pagamento(int id_forma_pagamento) {
	this.id_forma_pagamento = id_forma_pagamento;
}

public String getServico() {
	return servico;
}

public void setServico(String servico) {
	this.servico = servico;
}

public String getCuidador() {
	return cuidador;
}

public void setCuidador(String cuidador) {
	this.cuidador = cuidador;
}  
}
