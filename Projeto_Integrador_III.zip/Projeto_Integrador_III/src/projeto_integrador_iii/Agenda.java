package projeto_integrador_iii;
// Definição
public class Agenda {
  
  // Atributos
  private String dt_marcacao;
  private String hr_marcacao;

  // Construtor da classe
  public Agenda (String dt_marcacao, String hr_marcacao) {
    this.setDt_marcacao(dt_marcacao);
    this.setHr_marcacao(hr_marcacao);
    
  }

public String getDt_marcacao() {
	return dt_marcacao;
}

public void setDt_marcacao(String dt_marcacao) {
	this.dt_marcacao = dt_marcacao;
}

public String getHr_marcacao() {
	return hr_marcacao;
}

public void setHr_marcacao(String hr_marcacao) {
	this.hr_marcacao = hr_marcacao;
}
}
