package projeto_integrador_iii;
public class Pessoa {
  
  // Atributos
  private int id_pessoa;
  public String nome;
  public String endereco;
  public String telefone;
  public String dt_nascimento;
  public String cpf;


  // Construtor da classe
  public Pessoa() {
    this.setId_pessoa(id_pessoa);
    this.setNome(nome);
    this.setEndereco(endereco);
    this.setTelefone(telefone);
    this.setDt_nascimento(dt_nascimento);
    this.setCpf(cpf);
  }

  public void status () {
	   	System.out.println("Nome: " + this.nome);
	 	System.out.println("Endereco: " + this.endereco);
	 	System.out.println("Telefone: " + this.telefone);
	 	System.out.println("Data de nascimento: " + this.dt_nascimento);
	 	System.out.println("CPF: " + this.cpf);
	   	}
public String getCpf() {
	return cpf;
}

public void setCpf(String cpf) {
	this.cpf = cpf;
}

public String getDt_nascimento() {
	return dt_nascimento;
}

public void setDt_nascimento(String dt_nascimento) {
	this.dt_nascimento = dt_nascimento;
}

public String getTelefone() {
	return telefone;
}

public void setTelefone(String telefone) {
	this.telefone = telefone;
}

public String getEndereco() {
	return endereco;
}

public void setEndereco(String endereco) {
	this.endereco = endereco;
}

public String getNome() {
	return nome;
}

public void setNome(String nome) {
	this.nome = nome;
}

public int getId_pessoa() {
	return id_pessoa;
}

public void setId_pessoa(int id_pessoa) {
	this.id_pessoa = id_pessoa;
} 
}
