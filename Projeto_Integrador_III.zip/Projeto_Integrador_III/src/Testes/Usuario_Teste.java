package Testes;

import projeto_integrador_iii.Usuario;

public class Usuario_Teste {
	public static void main (String[] args) {
	Usuario u1 = new Usuario();
	u1.nome = "Marco";
	u1.login = "marcoajr";
	u1.senha = "123";	
	u1.status();
	}
}