package Testes;

import projeto_integrador_iii.Pagamento;

public class Pagamento_Teste {

	public static void main (String[] args) {
		Pagamento p1 = new Pagamento();
		p1.desc_forma_pagamento = "Boleto";
		p1.status();
		}
}