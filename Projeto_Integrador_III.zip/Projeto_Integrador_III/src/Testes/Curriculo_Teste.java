package Testes;

import projeto_integrador_iii.Curriculo;

public class Curriculo_Teste {
	public static void main (String[] args) {
		Curriculo c1 = new Curriculo();
		c1.experiencia = "Prestador de servi�os autonomo";
		c1.qualificacoes = "......................";
		c1.vl_servico = "R$50,00/ hora.";
		c1.status();
		}
	}