package Testes;
import projeto_integrador_iii.Contratante;

	public class Contratante_Teste {
		public static void main (String[] args) {
		Contratante c1 = new Contratante();
		c1.servico = "Cuidador de Idosos";
		c1.cuidador = "Marco Aur�lio";
		c1.status();
		}
	}