package Testes;

import projeto_integrador_iii.Cuidador;

public class Cuidador_Teste {
	public static void main (String[] args) {
		Cuidador c1 = new Cuidador();
		c1.usuario = "marcoajr";
		c1.cuidador = "Marco Aur�lio";
		c1.agenda = "N�o h� hor�rios dispon�veis";
		c1.curriculo = "Descri��o do curr�culo........";
		c1.status();
		}
	}